# -*- coding: utf-8 -*-
"""
This check is deprecated, see `IdentifierLabelCorrelation
<https://docs.deepchecks.com/en/stable/checks_gallery/tabular/data_integrity/plot_identifier_label_correlation.html>`__
"""
